import "./Experience.css";

function Experience() {
  const responsibilities = [
    "Developed and maintained a full-stack College Portal using React.js, Spring Boot, Java and MySQL.",
    "Implemented course management, attendance tracking, results and notice management features.",
    "Developed and integrated REST APIs to connect frontend and backend services.",
    "Debugged application issues and improved the reliability of academic workflows.",
    "Collaborated with team members using Git-based development practices.",
  ];

  const technologies = [
    "Java",
    "Spring Boot",
    "React.js",
    "MySQL",
    "REST APIs",
    "Git",
  ];

  return (
    <section className="experience" id="experience">
      <div className="experience-container">
        <div className="experience-heading">
          <p>My Professional Journey</p>
          <h2>Work Experience</h2>
          <div className="experience-heading-line"></div>
        </div>

        <div className="experience-timeline">
          <div className="timeline-marker">
            <span></span>
          </div>

          <article className="experience-card">
            <div className="experience-card-header">
              <div>
                <p className="experience-type">Internship</p>
                <h3>Java Software Developer Intern</h3>
                <h4>Hinduja Tech Limited</h4>
              </div>

              <div className="experience-date">
                <span>June 2026</span>
                <span>October 2026</span>
              </div>
            </div>

            <p className="experience-location">
              Perungalathur, Chennai, Tamil Nadu
            </p>

            <div className="experience-divider"></div>

            <h5>Key Responsibilities</h5>

            <ul className="responsibility-list">
              {responsibilities.map((responsibility) => (
                <li key={responsibility}>
                  <span className="list-marker"></span>
                  <p>{responsibility}</p>
                </li>
              ))}
            </ul>

            <div className="experience-technologies">
              <h5>Technologies Used</h5>

              <div className="technology-list">
                {technologies.map((technology) => (
                  <span className="technology-item" key={technology}>
                    {technology}
                  </span>
                ))}
              </div>
            </div>
          </article>
        </div>
      </div>
    </section>
  );
}

export default Experience;