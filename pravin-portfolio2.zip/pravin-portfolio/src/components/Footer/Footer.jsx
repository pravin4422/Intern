import "./Footer.css";

function Footer() {
  const currentYear = new Date().getFullYear();

  const scrollToSection = (sectionId) => {
    const section = document.getElementById(sectionId);

    if (section) {
      section.scrollIntoView({
        behavior: "smooth",
      });
    }
  };

  return (
    <footer className="footer">
      <div className="footer-container">
        <div className="footer-top">
          <div className="footer-about">
            <button
              type="button"
              className="footer-logo"
              onClick={() => scrollToSection("home")}
            >
              Pravin<span> R</span>
            </button>

            <p>
              Software Developer and AI/ML enthusiast focused on building
              responsive, reliable and user-friendly applications.
            </p>
          </div>

          <div className="footer-navigation">
            <h3>Quick Links</h3>

            <ul>
              <li>
                <button
                  type="button"
                  onClick={() => scrollToSection("home")}
                >
                  Home
                </button>
              </li>

              <li>
                <button
                  type="button"
                  onClick={() => scrollToSection("about")}
                >
                  About
                </button>
              </li>

              <li>
                <button
                  type="button"
                  onClick={() => scrollToSection("skills")}
                >
                  Skills
                </button>
              </li>

              <li>
                <button
                  type="button"
                  onClick={() => scrollToSection("experience")}
                >
                  Experience
                </button>
              </li>

              <li>
                <button
                  type="button"
                  onClick={() => scrollToSection("projects")}
                >
                  Projects
                </button>
              </li>

              <li>
                <button
                  type="button"
                  onClick={() => scrollToSection("education")}
                >
                  Education
                </button>
              </li>

              <li>
                <button
                  type="button"
                  onClick={() => scrollToSection("contact")}
                >
                  Contact
                </button>
              </li>
            </ul>
          </div>

          <div className="footer-social">
            <h3>Connect With Me</h3>

            <div className="footer-social-links">
              <button
                type="button"
                onClick={() => alert("LinkedIn link will be added soon.")}
              >
                LinkedIn
              </button>

              <button
                type="button"
                onClick={() => alert("GitHub link will be added soon.")}
              >
                GitHub
              </button>

              <button
                type="button"
                onClick={() => alert("LeetCode link will be added soon.")}
              >
                LeetCode
              </button>
            </div>
          </div>
        </div>

        <div className="footer-divider"></div>

        <div className="footer-bottom">
          <p>
            &copy; {currentYear} Pravin R. All rights reserved.
          </p>

          <button
            type="button"
            className="back-to-top"
            onClick={() => scrollToSection("home")}
          >
            Back to top
          </button>
        </div>
      </div>
    </footer>
  );
}

export default Footer;