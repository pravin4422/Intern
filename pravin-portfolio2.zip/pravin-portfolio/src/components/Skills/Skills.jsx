import "./Skills.css";

function Skills() {
  const skillCategories = [
    {
      id: 1,
      title: "Programming Languages",
      skills: ["Java", "Python", "C"],
    },
    {
      id: 2,
      title: "Frontend Development",
      skills: ["React.js", "JavaScript", "HTML5", "CSS3"],
    },
    {
      id: 3,
      title: "Backend Development",
      skills: ["Spring Boot", "Node.js", "Express.js", "REST APIs"],
    },
    {
      id: 4,
      title: "Databases",
      skills: ["MySQL", "PostgreSQL", "MongoDB"],
    },
    {
      id: 5,
      title: "Tools & Platforms",
      skills: ["Git", "GitHub", "Postman", "VS Code", "IntelliJ IDEA"],
    },
    {
      id: 6,
      title: "Core Concepts",
      skills: [
        "Object-Oriented Programming",
        "Data Structures",
        "Algorithms",
        "Machine Learning",
        "RAG",
      ],
    },
  ];

  return (
    <section className="skills" id="skills">
      <div className="skills-container">
        <div className="skills-heading">
          <p>What I Work With</p>
          <h2>Technical Skills</h2>
          <div className="skills-heading-line"></div>
        </div>

        <p className="skills-introduction">
          These are the technologies, tools and programming concepts I use to
          build software applications and improve my development skills.
        </p>

        <div className="skills-grid">
          {skillCategories.map((category, index) => (
            <article className="skill-card" key={category.id}>
              <div className="skill-card-header">
                <span className="skill-card-number">
                  {String(index + 1).padStart(2, "0")}
                </span>

                <h3>{category.title}</h3>
              </div>

              <div className="skill-list">
                {category.skills.map((skill) => (
                  <span className="skill-item" key={skill}>
                    {skill}
                  </span>
                ))}
              </div>
            </article>
          ))}
        </div>
      </div>
    </section>
  );
}

export default Skills;