import "./About.css";

function About() {
  return (
    <section className="about" id="about">
      <div className="about-container">
        <div className="section-heading">
          <p>Get To Know More</p>
          <h2>About Me</h2>
          <div className="heading-line"></div>
        </div>

        <div className="about-content">
          <div className="about-card">
            <span className="about-number">01</span>

            <h3>Who I Am</h3>

            <p>
              I am a motivated software developer with hands-on experience in
              full-stack development and a strong foundation in Java,
              object-oriented programming, data structures and algorithms.
            </p>
          </div>

          <div className="about-information">
            <h3>Building software with purpose and curiosity</h3>

            <p>
              I am currently pursuing a Master of Computer Applications at the
              College of Engineering Guindy. My academic background in
              mathematics helps me approach programming and problem-solving
              with logical and analytical thinking.
            </p>

            <p>
              I enjoy developing responsive web applications using React,
              Java and Spring Boot. I am also expanding my knowledge in Python,
              machine learning and AI-based applications.
            </p>

            <div className="about-highlights">
              <div className="highlight-item">
                <span className="highlight-number">200+</span>
                <span className="highlight-label">DSA Problems</span>
              </div>

              <div className="highlight-item">
                <span className="highlight-number">3+</span>
                <span className="highlight-label">Major Projects</span>
              </div>

              <div className="highlight-item">
                <span className="highlight-number">MCA</span>
                <span className="highlight-label">CEG Chennai</span>
              </div>
            </div>

            <a className="about-button" href="#contact">
              Let&apos;s Connect
            </a>
          </div>
        </div>
      </div>
    </section>
  );
}

export default About;