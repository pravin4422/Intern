import { useState } from "react";
import "./Contact.css";

function Contact() {
  const [formData, setFormData] = useState({
    name: "",
    email: "",
    subject: "",
    message: "",
  });

  const [statusMessage, setStatusMessage] = useState("");

  const handleChange = (event) => {
    const { name, value } = event.target;

    setFormData((previousData) => ({
      ...previousData,
      [name]: value,
    }));

    setStatusMessage("");
  };

  const handleSubmit = (event) => {
    event.preventDefault();

    const { name, email, subject, message } = formData;

    if (
      !name.trim() ||
      !email.trim() ||
      !subject.trim() ||
      !message.trim()
    ) {
      setStatusMessage("Please complete all the fields.");
      return;
    }

    const emailSubject = encodeURIComponent(subject);

    const emailBody = encodeURIComponent(
      `Name: ${name}\nEmail: ${email}\n\nMessage:\n${message}`
    );

    window.location.href = `mailto:your-email@gmail.com?subject=${emailSubject}&body=${emailBody}`;

    setStatusMessage("Your email application is opening.");
  };

  return (
    <section className="contact" id="contact">
      <div className="contact-container">
        <div className="contact-heading">
          <p>Get In Touch</p>
          <h2>Contact Me</h2>
          <div className="contact-heading-line"></div>
        </div>

        <p className="contact-introduction">
          I am open to software-development opportunities, collaborative
          projects and conversations about Java, full-stack development,
          artificial intelligence and machine learning.
        </p>

        <div className="contact-content">
          <div className="contact-information">
            <p className="contact-small-title">Let&apos;s Connect</p>

            <h3>Have a project or opportunity in mind?</h3>

            <p className="contact-description">
              Send me a message using the contact form. I will respond as soon
              as possible.
            </p>

            <div className="contact-details">
              <div className="contact-detail-card">
                <span className="contact-detail-number">01</span>

                <div>
                  <p>Email</p>

                  <a href="mailto:your-email@gmail.com">
                    rpravin4422@gmail.com
                  </a>
                </div>
              </div>

              <div className="contact-detail-card">
                <span className="contact-detail-number">02</span>

                <div>
                  <p>Location</p>
                  <span>Chennai, Tamil Nadu</span>
                </div>
              </div>

              <div className="contact-detail-card">
                <span className="contact-detail-number">03</span>

                <div>
                  <p>Availability</p>
                  <span>Open to opportunities</span>
                </div>
              </div>
            </div>

            <div className="contact-social-links">
              <a
                href="https://www.linkedin.com/"
                target="_blank"
                rel="noreferrer"
              >
                LinkedIn
              </a>

              <a
                href="https://github.com/"
                target="_blank"
                rel="noreferrer"
              >
                GitHub
              </a>

              <a
                href="https://leetcode.com/"
                target="_blank"
                rel="noreferrer"
              >
                LeetCode
              </a>
            </div>
          </div>

          <form className="contact-form" onSubmit={handleSubmit}>
            <div className="form-group">
              <label htmlFor="name">Your Name</label>

              <input
                type="text"
                id="name"
                name="name"
                value={formData.name}
                onChange={handleChange}
                placeholder="Enter your name"
              />
            </div>

            <div className="form-group">
              <label htmlFor="email">Your Email</label>

              <input
                type="email"
                id="email"
                name="email"
                value={formData.email}
                onChange={handleChange}
                placeholder="Enter your email"
              />
            </div>

            <div className="form-group">
              <label htmlFor="subject">Subject</label>

              <input
                type="text"
                id="subject"
                name="subject"
                value={formData.subject}
                onChange={handleChange}
                placeholder="Enter the subject"
              />
            </div>

            <div className="form-group">
              <label htmlFor="message">Message</label>

              <textarea
                id="message"
                name="message"
                rows="6"
                value={formData.message}
                onChange={handleChange}
                placeholder="Write your message"
              ></textarea>
            </div>

            <button type="submit" className="contact-submit-button">
              Send Message
            </button>

            {statusMessage && (
              <p className="contact-status-message">{statusMessage}</p>
            )}
          </form>
        </div>
      </div>
    </section>
  );
}

export default Contact;