import "./Home.css";
import profilePhoto from "../../assets/profile-photo.jpeg";
function Home() {
  return (
    <section className="home" id="home">
      <div className="home-container">
        <div className="home-content">
          <p className="home-greeting">Hello, I'm</p>

          <h1 className="home-name">
            Pravin <span>R</span>
          </h1>

          <h2 className="home-role">
            Software Developer & AI/ML Enthusiast
          </h2>

          <p className="home-description">
            I build responsive web applications and software solutions using
            Java, React, Spring Boot, Python and modern technologies.
          </p>

          <div className="home-buttons">
              <a
                href="/Pravin_Deloit.pdf"
                className="primary-button"
                target="_blank"
                rel="noopener noreferrer"
              >
                View My Resume
              </a>

            <a href="#contact" className="secondary-button">
              Contact Me
            </a>
          </div>
        </div>

        <div className="home-visual" aria-hidden="true">
          <div className="profile-card">
                      <div className="profile-circle">
            <img
              src={profilePhoto}
              alt="Pravin R"
              className="profile-photo"
            />
          </div>

            <div className="code-line">
              <span className="code-keyword">const</span>
              <span className="code-name"> developer</span> = {"{"}
            </div>

            <div className="code-detail">
              name: <span>"Pravin R"</span>,
            </div>

            <div className="code-detail">
              role: <span>"Software Developer"</span>,
            </div>

            <div className="code-detail">
              passion: <span>"AI/ML"</span>
            </div>

            <div className="code-line">{"};"}</div>
          </div>
        </div>
      </div>
    </section>
  );
}

export default Home;